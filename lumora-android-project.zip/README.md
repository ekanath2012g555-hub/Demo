# Lumora Studio – Android app (Capacitor)

The website lives in `www/index.html`. Capacitor wraps it in a native Android app.

## Option A: build in the cloud (no installs)
1. Create a free GitHub repository and upload this folder's contents.
2. Open the Actions tab, run "Build APK".
3. Download `lumora-debug-apk` from the finished run, unzip it, and install `app-debug.apk` on your phone (allow "install unknown apps").

## Option B: build on your computer
Requires Node 20+, JDK 21 and Android Studio.
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android
In Android Studio: Build > Build APK(s). Output: android/app/build/outputs/apk/debug/app-debug.apk

## Before publishing to Google Play
Create a signed release build (Build > Generate Signed Bundle / APK) and add real app icons (Capacitor's `@capacitor/assets` tool can generate them).
